import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public logo:string='https://cdn-icons-png.flaticon.com/512/2981/2981297.png';
  public propietario:string = ' Jonathan Castillo';
  constructor() { }

  ngOnInit(): void {
  }

}
