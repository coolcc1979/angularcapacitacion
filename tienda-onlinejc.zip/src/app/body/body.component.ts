import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {
  public nombreCliente:string="Will Smith";
  public producto:string="Lamborghini";
  public precio:number=23;
  public deshabilitado= true;
  public comentario:string="Comentario de ";

  constructor() { 
  }

  ngOnInit(): void {
  }
  cliente1():void{
    this.nombreCliente = "Juan Armendariz";
    this.producto = "TV";
    this.precio = 350;
    this.deshabilitado = true;
    setInterval(()=>this.deshabilitado = false, 5000);
  }
  cliente2():void{
    this.nombreCliente = "Neymar Jr";
    this.producto = "Corvette";
    this.precio = 1500000;
    this.deshabilitado = true;
    setInterval(()=>this.deshabilitado = false, 5000);
  }
  cliente3():void{
    this.nombreCliente = "Freddy Mercury";
    this.producto = "Lavadora";
    this.precio = 500;
    this.deshabilitado = true;  
    setInterval(()=>this.deshabilitado = false, 5000);
  }
}
